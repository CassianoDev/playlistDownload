========================================================================

The following Programs are protected by the GNU General Public License
(see the file GPL.txt in the current directory)

========================================================================

From the Cygnus distribution:
(the relative source can be found through: http://sourceware.cygnus.com/cygwin/cvs.html)

chgrp.exe
chmod.exe
chown.exe
cpp.exe
cygwin1.dll
date.exe
diff3.exe
echo.exe
ed.exe
false
wc.exe
xargs.exe
true

========================================================================

From the GNU organization:
(the relative source can be found through: ftp://ftp.gnu.org/pub/gnu)

make.exe
flex.exe


========================================================================

From Tivoli (based on the GNU source as modified by Cygnus):
(the relative source can be found through: http://www.tivoli.com)

pwd.exe

========================================================================

The following Programs are protected by the GNU General Public License
(see the file GPL.txt in the current directory)

========================================================================


The following programs are downloaded from www.cygwin.com and are part 
of the cygwin environment

cygwinb19.dll
rm.exe

------------------------------------------------------------------------

The following files are downloaded from ftp://ftp.cc.utexas.edu/microlib/nt/gnu,
source can be found at the same location:

basename.exe
cat.exe
cmp.exe
cp.exe
cut.exe
dd.exe
diff.exe
du.exe
egrep.exe
env.exe
fgrep.exe
find.exe
grep.exe (copy of egrep.exe)
id.exe
less.exe
ls.exe
mv.exe
printenv.exe
rmdir.exe
sleep.exe
sort.exe
tee.exe
touch.exe
tr.exe
vi.exe
win32gnu.dll

------------------------------------------------------------------------

The following files are downloaded from http://unxutils.sourceforge.net:

ansi2knr.exe
awk.exe (copy of gawk.exe)
bc.exe
bison.exe
comm.exe
csplit.exe
dc.exe
df.exe
dircolors.exe
dirname.exe
expand.exe
expr.exe
factor.exe
fmt.exe
fold.exe
gawk.exe
gsar.exe
gunzip.exe
gzip.exe
head.exe
indent.exe
install.exe
jwhois.exe
join.exe
ln.exe
less.exe
logname.exe
m4.exe
md5sum.exe
mkdir.exe
mkfifo.exe
mknod.exe
more.exe (copy of less.exe)
mvdir.exe
nl.exe
od.exe
paste.exe
patch.exe
pwd.exe
recode.exe
sed.exe
seq.exe
shar.exe
split.exe
su.exe
sum.exe
sync.exe
tac.exe
tail.exe
tar.exe
test.exe
type.exe
unexpand.exe
uniq.exe
unshar.exe
uuencode.exe
uudecode.exe
wc.exe
which.exe
wget.exe
wget.hlp
whoami.exe
xargs.exe
yes.exe

========================================================================
The following files are compiled by CENIT from GPLed source code
available via http://win-bash.sourceforge.net
========================================================================

bash.exe
sh.exe
