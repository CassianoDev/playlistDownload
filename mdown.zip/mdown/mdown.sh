#!/bin/bash
#cassiano.dev
set -ue
usage() {
    name=${i:-'mdown.sh'}
    echo "Use: $name minhaplaylist.m3u /pasta/para/salvar" >&2
    exit 1
}
if [ -z "${1:+x}" ]; then
    echo "Nenhuma playlist." >&2
    usage
fi
if [ -z "${2+x}" ]; then
    echo "Voce nao setou um diretorio de saida." >&2
    usage
fi
playlist=$1
outputdir=${2%/}
if [ ! -d $outputdir ]; then
  echo -e "Criando pasta $outputdir.\n"
  mkdir -p $outputdir
fi
declare -i lines="$(wc -l < $playlist)"
declare -i videos="($lines-1)/2"
video="1"
declare -i tot="($videos + 1)";
while [ $video -lt $tot ]
do
  videotitle="$(awk "NR==$video*2 {print}" $playlist | cut -d',' -f2-)"
  videolink="$(awk "NR==$video*2+1 {print}" $playlist)"
  videotitle="$(echo "$videotitle" | sed 's/[^a-zA-Z0-9]/ /g' )"
  extension="${videolink##*.}"
  echo -e "$video/$videos\tBaixando $videotitle"
  wget -O "$outputdir/$videotitle.$extension" --header="Accept: text/html" --user-agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:21.0) Gecko/20100101 Firefox/21.0" $videolink
video=$[$video+1]
done
echo -e "\nTodos os videos foram baixados."